<?php
header("Content-Type: application/json");
include 'config.php';

$sql = "SELECT * FROM packages";
$result = $conn->query($sql);

$packages = [];
while ($row = $result->fetch_assoc()) {
    $packages[] = $row;
}

echo json_encode($packages);
$conn->close();
?>