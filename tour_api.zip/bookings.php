<?php
header("Content-Type: application/json");
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $package_id = $_POST['package_id'] ?? '';
    $customer_name = $_POST['customer_name'] ?? '';
    $customer_email = $_POST['customer_email'] ?? '';
    $customer_phone = $_POST['customer_phone'] ?? '';
    $booking_date = date("Y-m-d");
    $travel_date = $_POST['travel_date'] ?? '';
    $people = $_POST['number_of_people'] ?? 1;
    $amount = $_POST['total_amount'] ?? 0.00;

    $stmt = $conn->prepare("INSERT INTO bookings (package_id, customer_name, customer_email, customer_phone, booking_date, travel_date, number_of_people, total_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssii", $package_id, $customer_name, $customer_email, $customer_phone, $booking_date, $travel_date, $people, $amount);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Booking successful"]);
    } else {
        echo json_encode(["success" => false, "message" => "Booking failed"]);
    }
    $stmt->close();
}
$conn->close();
?>