<?php
header("Content-Type: application/json");
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $message = $_POST['message'] ?? '';

    $stmt = $conn->prepare("INSERT INTO contact (Name, Email, Phone, Subject, Message) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $phone, $subject, $message);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Contact form submitted successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to submit form"]);
    }
    $stmt->close();
}
$conn->close();
?>